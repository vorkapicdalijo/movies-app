create function lo_oid(lo) returns oid
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT $1::pg_catalog.oid$$;

alter function lo_oid(lo) owner to postgres;

